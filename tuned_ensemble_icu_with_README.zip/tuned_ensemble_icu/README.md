# TunedEnsemble ICU Saline Infusion Anomaly Detection

This code package contains Python modules for constructing hourly patient windows, extracting summary features, defining machine-learning models, and calculating evaluation metrics for an ICU saline-infusion anomaly-detection study.

> **Important scope note:** This archive contains model and evaluation modules, but it does not include the clinical dataset, a complete end-to-end training pipeline, or the saved prediction files needed to run the standalone validation script out of the box. Results should not be described as reproduced until the code has been run against the appropriate data and independently checked.

## Package contents

| File | Purpose |
|---|---|
| `windowing.py` | Generates heuristic/weak anomaly labels, builds fixed-length sliding windows, splits windows by patient/stay, and normalizes using training-set statistics. |
| `feature_engineering.py` | Extracts eight summary statistics per channel: mean, standard deviation, minimum, maximum, first value, last value, delta, and linear slope. |
| `models.py` | Defines the model implementations and constructors for Logistic Regression, Random Forest, LSTM, BiLSTM, Transformer, PAT-TC, and TunedEnsemble. |
| `evaluate.py` | Provides overall classification metrics, early-horizon AUROC, time-to-detection, false-alarm rate, noise/missingness robustness checks, DeLong-style AUROC comparison, and bootstrap F1 comparison helpers. |
| `standalone_validator.py` | Loads saved test predictions and prints comparisons with reference values embedded in the script. Requires path configuration and a compatible prediction file. |

## Requirements

Use Python 3.10 or later (Python 3.11 is a reasonable choice). The modules import the following packages:

- NumPy
- pandas
- scikit-learn
- SciPy
- PyTorch

Install the dependencies in a virtual environment:

```bash
python -m venv .venv
```

Activate it, then run:

**Windows PowerShell**
```powershell
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install numpy pandas scikit-learn scipy torch
```

**Linux/macOS**
```bash
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install numpy pandas scikit-learn scipy torch
```

For GPU execution, install the PyTorch build appropriate for your system from the official PyTorch installation selector. The supplied code does not require a GPU for all model types.

## Expected data format

The data-preparation functions expect data already converted to hourly, wide-format patient/stay tables:

- Each row represents one time point (typically one hour).
- Columns contain the clinical variables and infusion-related fields used by the code.
- `windowing.py` refers to fields such as `saline_infusion_rate`, `saline_total_volume`, `urine_output`, `sodium`, and `mean_arterial_pressure` when generating weak labels.
- `build_windows()` also requires a `feature_order` list containing the input columns to use. Every selected row in a window must be numeric and non-missing; windows containing `NaN` are skipped.
- The `patient_tables` argument is a dictionary mapping a stay/patient identifier to a pandas DataFrame. The DataFrame index is used as the time/hour value.

The package does **not** include MIMIC-IV or any other clinical data. Obtain access through the relevant data provider, follow its credentialing and data-use requirements, and perform all required de-identification and governance steps. Do not place patient-identifiable data in a public repository.

## Typical workflow

The modules are building blocks rather than a single executable pipeline. A typical research workflow is:

1. Prepare and quality-check the authorized clinical data; aggregate it to the expected hourly format.
2. Define the input feature columns and create per-stay DataFrames.
3. Use `build_windows()` to create the window tensor, labels, stay IDs, and time values.
4. Use `patient_wise_split()` to split at the patient/stay level so windows from one stay do not cross data splits.
5. Fit normalization parameters on the training split only using `zscore_normalize()` and apply the same parameters to validation and test data.
6. Train/tune the desired models using the constructors and training functions available in `models.py`.
7. Generate probabilities on the held-out test split and calculate metrics with `evaluate.py`.
8. Record the random seeds, split identifiers, preprocessing settings, model parameters, thresholds, and package versions to support reproducibility.

No one-line command is provided to train and evaluate every model because the archive does not contain a complete orchestration script or the source dataset.

## Standalone validation script

`standalone_validator.py` expects the following files in a results directory:

- `test_predictions.npz`, containing arrays named `y_true`, `stay_ids`, `hours`, and `proba_<model>` for each of the seven model names used in the script (`LogisticRegression`, `RandomForest`, `LSTM`, `BiLSTM`, `Transformer`, `PAT-TC`, `TunedEnsemble`).
- Optionally, `metrics.csv` and `significance_tests.csv` for additional reported metrics (the script reads `metrics.csv`; the significance file is referenced by the script but is not required for its core calculations).

**Before running it:** open `standalone_validator.py` and change the hard-coded `source_dir` near the start of `run_validation()` to the location of your own results directory. Run it from the project folder:

```bash
python standalone_validator.py
```

The validator compares recalculated metrics against reference values hard-coded in the script. It is a checking utility, not a data-generation or model-training script. Some printed status messages are unconditional, so inspect the numerical differences and the underlying predictions rather than treating a status line alone as proof that the results match. The code's statistical tests and metrics should also be reviewed for suitability to the study design before publication.

## Notes on interpretation and reproducibility

- The weak labels in `windowing.py` are rule-based proxies, not a substitute for independently adjudicated clinical outcomes. Review the thresholds and clinical rationale with qualified domain experts.
- Use patient-wise splits and avoid preprocessing leakage from validation/test data.
- Clinical prediction performance is not evidence of clinical utility or safety by itself. Do not use this code for real-time patient care without appropriate validation, clinical oversight, and regulatory review where applicable.
- AUROC and threshold-based metrics require suitable label distributions; some functions can return `NaN` when there are too few observations or only one class.
- The current validator uses fixed thresholds and embedded reference metrics. Ensure the paper's reported evaluation protocol matches the actual implementation before claiming exact reproducibility.

## Suggested citation

If this code is associated with a manuscript, cite the corresponding paper and include the software version/commit used for the reported experiments. Do not cite this README as evidence that any experimental results have been independently reproduced.

## License

No license file is included in this archive. Unless the authors add a license, reuse and redistribution permissions are not explicitly granted. Check the source dataset's license and terms separately.
