"""
models.py
Defines all seven models evaluated in the paper:
  1. Logistic Regression
  2. Random Forest
  3. LSTM
  4. BiLSTM
  5. Transformer
  6. PAT-TC (Physiology-Aware Temporal Transformer with Contrastive Pretraining)
  7. TunedEnsemble (Validation-tuned HistGradientBoosting/RandomForest ensemble)
"""

from __future__ import annotations
import itertools
import math
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier
from sklearn.metrics import roc_auc_score

# ===========================================================================
# 1. Classical Baselines
# ===========================================================================

def flatten_windows(X: np.ndarray) -> np.ndarray:
    """[N, w, d] -> [N, w*d] for classical baseline models."""
    return X.reshape(X.shape[0], -1)

def make_logistic_regression(seed: int = 42):
    return LogisticRegression(max_iter=2000, class_weight="balanced", random_state=seed)

def make_random_forest(seed: int = 42):
    return RandomForestClassifier(
        n_estimators=300, max_depth=12, class_weight="balanced",
        random_state=seed, n_jobs=-1,
    )

# ===========================================================================
# 2. Recurrent & Transformer Baselines
# ===========================================================================

class RNNClassifier(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int = 64, num_layers: int = 2,
                 dropout: float = 0.2, bidirectional: bool = False):
        super().__init__()
        self.rnn = nn.LSTM(
            input_size=input_dim, hidden_size=hidden_dim, num_layers=num_layers,
            batch_first=True, dropout=dropout if num_layers > 1 else 0.0,
            bidirectional=bidirectional,
        )
        out_dim = hidden_dim * (2 if bidirectional else 1)
        self.head = nn.Sequential(nn.LayerNorm(out_dim), nn.Linear(out_dim, 1))

    def forward(self, x):
        out, _ = self.rnn(x)
        last = out[:, -1, :]
        return self.head(last).squeeze(-1)

class PositionalEncoding(nn.Module):
    def __init__(self, d_model: int, max_len: int = 512):
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        pos = torch.arange(0, max_len).unsqueeze(1).float()
        div = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(pos * div)
        pe[:, 1::2] = torch.cos(pos * div)
        self.register_buffer("pe", pe.unsqueeze(0))

    def forward(self, x):
        return x + self.pe[:, :x.size(1)]

class TransformerClassifier(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int = 64, num_layers: int = 3,
                 num_heads: int = 4, ff_dim: int = 128, dropout: float = 0.2):
        super().__init__()
        self.input_proj = nn.Linear(input_dim, hidden_dim)
        self.pos_enc = PositionalEncoding(hidden_dim)
        layer = nn.TransformerEncoderLayer(
            d_model=hidden_dim, nhead=num_heads, dim_feedforward=ff_dim,
            dropout=dropout, batch_first=True,
        )
        self.encoder = nn.TransformerEncoder(layer, num_layers=num_layers)
        self.head = nn.Sequential(nn.LayerNorm(hidden_dim), nn.Linear(hidden_dim, 1))

    def forward(self, x):
        h = self.pos_enc(self.input_proj(x))
        h = self.encoder(h)
        pooled = h.mean(dim=1)
        return self.head(pooled).squeeze(-1)

# ===========================================================================
# 3. Physiology-Aware Baseline (PAT-TC)
# ===========================================================================

class ContrastiveEncoder(nn.Module):
    def __init__(self, input_dim: int, latent_dim: int = 64, hidden_dim: int = 64):
        super().__init__()
        self.conv = nn.Conv1d(input_dim, hidden_dim, kernel_size=3, padding=1)
        self.gru = nn.GRU(hidden_dim, hidden_dim, batch_first=True, bidirectional=True)
        self.proj = nn.Linear(hidden_dim * 2, latent_dim)

    def forward(self, x):
        h = self.conv(x.transpose(1, 2)).transpose(1, 2)
        h = F.gelu(h)
        out, _ = self.gru(h)
        z_seq = self.proj(out)
        z_pooled = z_seq.mean(dim=1)
        return z_seq, z_pooled

def build_physio_bias(feature_names: list[str], physiology_edges: dict[str, list[str]], strength: float = 4.0):
    idx = {name: i for i, name in enumerate(feature_names)}
    d = len(feature_names)
    B = torch.zeros(d, d)
    for src, targets in physiology_edges.items():
        if src not in idx:
            continue
        for tgt in targets:
            if tgt in idx:
                B[idx[src], idx[tgt]] = strength
                B[idx[tgt], idx[src]] = strength
    return B

class PhysioAwareAttention(nn.Module):
    def __init__(self, d_model: int, num_heads: int, feature_dim: int, physio_bias: torch.Tensor, dropout: float = 0.1):
        super().__init__()
        self.mha = nn.MultiheadAttention(d_model, num_heads, dropout=dropout, batch_first=True)
        importance = physio_bias.sum(dim=1)
        importance = importance / (importance.max() + 1e-6)
        self.register_buffer("physio_importance", importance)
        self.channel_to_model = nn.Linear(feature_dim, d_model)
        self.gate_scale = nn.Parameter(torch.tensor(1.0))

    def forward(self, h, raw_features):
        gate_input = raw_features * self.physio_importance.view(1, 1, -1)
        gate = torch.sigmoid(self.channel_to_model(gate_input)) * self.gate_scale
        h_gated = h * (1.0 + gate)
        attn_out, attn_weights = self.mha(h_gated, h_gated, h_gated, need_weights=True, average_attn_weights=True)
        return attn_out, attn_weights

class PhysioAwareTransformerBlock(nn.Module):
    def __init__(self, d_model: int, num_heads: int, ff_dim: int, feature_dim: int, physio_bias: torch.Tensor, dropout: float = 0.1):
        super().__init__()
        self.attn = PhysioAwareAttention(d_model, num_heads, feature_dim, physio_bias, dropout)
        self.norm1 = nn.LayerNorm(d_model)
        self.ff = nn.Sequential(nn.Linear(d_model, ff_dim), nn.GELU(), nn.Dropout(dropout), nn.Linear(ff_dim, d_model))
        self.norm2 = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)

    def forward(self, h, raw_features):
        attn_out, attn_weights = self.attn(h, raw_features)
        h = self.norm1(h + self.dropout(attn_out))
        ff_out = self.ff(h)
        h = self.norm2(h + self.dropout(ff_out))
        return h, attn_weights

class BiLSTMRefinement(nn.Module):
    def __init__(self, d_model: int, dropout: float = 0.1):
        super().__init__()
        self.bilstm = nn.LSTM(d_model, d_model // 2, batch_first=True, bidirectional=True)
        self.dropout = nn.Dropout(dropout)

    def forward(self, h):
        r, _ = self.bilstm(h)
        r = self.dropout(r)
        return h + r

class PAT_TC(nn.Module):
    def __init__(self, feature_names: list[str], physiology_edges: dict[str, list[str]],
                 hidden_dim: int = 64, latent_dim: int = 64, num_layers: int = 3,
                 num_heads: int = 4, ff_dim: int = 128, dropout: float = 0.2, physio_mask_strength: float = 4.0):
        super().__init__()
        feature_dim = len(feature_names)
        self.encoder = ContrastiveEncoder(feature_dim, latent_dim, hidden_dim=hidden_dim)
        self.latent_to_model = nn.Linear(latent_dim, hidden_dim)
        self.pos_enc = PositionalEncoding(hidden_dim)
        physio_bias = build_physio_bias(feature_names, physiology_edges, physio_mask_strength)
        self.blocks = nn.ModuleList([
            PhysioAwareTransformerBlock(hidden_dim, num_heads, ff_dim, feature_dim, physio_bias, dropout)
            for _ in range(num_layers)
        ])
        self.refine = BiLSTMRefinement(hidden_dim, dropout)
        self.head = nn.Sequential(nn.LayerNorm(hidden_dim), nn.Linear(hidden_dim, 1))

    def forward(self, x):
        z_seq, _ = self.encoder(x)
        h = self.pos_enc(self.latent_to_model(z_seq))
        for block in self.blocks:
            h, _ = block(h, x)
        u = self.refine(h)
        pooled = u.mean(dim=1)
        return self.head(pooled).squeeze(-1)

# ===========================================================================
# 4. Proposed Framework: TunedEnsemble
# ===========================================================================

RF_GRID = {
    "n_estimators": [200, 400],
    "max_depth": [6, 10, None],
    "min_samples_leaf": [1, 2, 5],
}
HGB_GRID = {
    "learning_rate": [0.03, 0.1],
    "max_depth": [3, 5, None],
    "max_iter": [100, 200],
    "l2_regularization": [0.0, 1.0],
}

class ProbaEnsemble:
    def __init__(self, models, weights):
        self.models = models
        weights = np.array(weights, dtype=float)
        self.weights = weights / weights.sum()

    def predict_proba(self, X):
        pos = np.zeros(len(X))
        for m, w in zip(self.models, self.weights):
            pos += w * m.predict_proba(X)[:, 1]
        return np.column_stack([1 - pos, pos])

def fit_tuned_ensemble(X_train: np.ndarray, y_train: np.ndarray,
                       X_val: np.ndarray, y_val: np.ndarray, seed: int = 42):
    """
    Exhaustive validation-driven grid search:
      - 18 RandomForest configurations
      - 24 HistGradientBoosting configurations
      - Soft-voting ensemble of best RF + best HGB
      Selects best model strictly by validation AUROC without touching test data.
    """
    def _grid(grid_dict):
        keys = list(grid_dict)
        for values in itertools.product(*grid_dict.values()):
            yield dict(zip(keys, values))

    # Tune RandomForest
    best_rf_auc, best_rf, best_rf_params = -1.0, None, None
    for params in _grid(RF_GRID):
        m = RandomForestClassifier(**params, class_weight="balanced", n_jobs=-1, random_state=seed)
        m.fit(X_train, y_train)
        auc = roc_auc_score(y_val, m.predict_proba(X_val)[:, 1])
        if auc > best_rf_auc:
            best_rf_auc, best_rf, best_rf_params = auc, m, params

    # Tune HistGradientBoosting
    pos_frac = max(y_train.mean(), 1e-4)
    sample_weight = np.where(y_train == 1, (1 - pos_frac) / pos_frac, 1.0)
    best_gb_auc, best_gb, best_gb_params = -1.0, None, None
    for params in _grid(HGB_GRID):
        m = HistGradientBoostingClassifier(**params, random_state=seed)
        m.fit(X_train, y_train, sample_weight=sample_weight)
        auc = roc_auc_score(y_val, m.predict_proba(X_val)[:, 1])
        if auc > best_gb_auc:
            best_gb_auc, best_gb, best_gb_params = auc, m, params

    # Evaluate soft-voting ensemble
    ensemble = ProbaEnsemble([best_rf, best_gb], weights=[best_rf_auc, best_gb_auc])
    ens_auc = roc_auc_score(y_val, ensemble.predict_proba(X_val)[:, 1])

    candidates = [
        ("RandomForest(tuned)", best_rf, best_rf_auc),
        ("HistGradientBoosting(tuned)", best_gb, best_gb_auc),
        ("RF+GB soft-voting ensemble", ensemble, ens_auc),
    ]
    name, chosen_model, chosen_auc = max(candidates, key=lambda c: c[2])
    info = {
        "selected": name,
        "val_auroc": chosen_auc,
        "rf_val_auroc": best_rf_auc,
        "gb_val_auroc": best_gb_auc,
        "rf_params": best_rf_params,
        "gb_params": best_gb_params,
    }
    return chosen_model, info
