"""
evaluate.py
Evaluation routines matching all paper dimensions:
  - Table 2: Overall Performance (Accuracy, Precision, Recall, F1, AUROC)
  - Table 3: Early-Detection AUROC at 1/2/3-Hour Horizons
  - Table 4: Time-to-Detection (Mean/Median hours)
  - Table 5: Robustness under 10% Noise and 20% Missingness
  - Table 6: False Alarm Rate per ICU-day
  - Table 7: DeLong AUROC Significance Test
  - Table 8: Bootstrap Resampling F1 Significance & 95% CI
"""

from __future__ import annotations
import numpy as np
import torch
from scipy import stats
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score

def overall_performance(y_true: np.ndarray, y_prob: np.ndarray, threshold: float = 0.5) -> dict:
    y_pred = (y_prob >= threshold).astype(int)
    return {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "precision": float(precision_score(y_true, y_pred, zero_division=0)),
        "recall": float(recall_score(y_true, y_pred, zero_division=0)),
        "f1": float(f1_score(y_true, y_pred, zero_division=0)),
        "auroc": float(roc_auc_score(y_true, y_prob)),
    }

def early_detection_auroc(model, X: np.ndarray, y: np.ndarray, hours: np.ndarray,
                         stay_ids: np.ndarray, horizons: list[int], predict_fn) -> dict:
    results = {}
    for h in horizons:
        max_hour_per_stay = {}
        for sid, hr in zip(stay_ids, hours):
            max_hour_per_stay[sid] = max(max_hour_per_stay.get(sid, 0), hr)
        keep = np.array([hr <= max_hour_per_stay[sid] - h for sid, hr in zip(stay_ids, hours)])
        if keep.sum() < 10 or len(np.unique(y[keep])) < 2:
            results[h] = float("nan")
            continue
        probs = predict_fn(model, X[keep])
        results[h] = float(roc_auc_score(y[keep], probs))
    return results

def time_to_detection(y_true: np.ndarray, y_prob: np.ndarray, stay_ids: np.ndarray,
                      hours: np.ndarray, threshold: float = 0.5) -> dict:
    ttds = []
    unique_ids = np.unique(stay_ids)
    for sid in unique_ids:
        mask = stay_ids == sid
        hrs = hours[mask]
        order = np.argsort(hrs)
        hrs = hrs[order]
        yt = y_true[mask][order]
        yp = y_prob[mask][order]

        true_onsets = hrs[yt == 1]
        if len(true_onsets) == 0:
            continue
        onset = true_onsets[0]
        after_onset = hrs >= onset
        detected = after_onset & (yp >= threshold)
        if detected.any():
            detect_hour = hrs[detected][0]
            ttds.append(detect_hour - onset)
    if not ttds:
        return {"mean_ttd_hours": float("nan"), "median_ttd_hours": float("nan")}
    ttds = np.array(ttds, dtype=float)
    return {"mean_ttd_hours": float(ttds.mean()), "median_ttd_hours": float(np.median(ttds))}

def false_alarm_rate_per_icu_day(y_true: np.ndarray, y_prob: np.ndarray, stay_ids: np.ndarray,
                                 hours: np.ndarray, threshold: float = 0.5) -> float:
    y_pred = (y_prob >= threshold).astype(int)
    fp = (y_pred == 1) & (y_true == 0)
    df_days = {}
    for sid in np.unique(stay_ids):
        mask = stay_ids == sid
        icu_hours = hours[mask].max() - hours[mask].min() + 1
        icu_days = max(icu_hours / 24.0, 1e-6)
        n_fp = fp[mask].sum()
        df_days[sid] = n_fp / icu_days
    rates = np.array(list(df_days.values()))
    return float(rates.mean())

def inject_noise(X: np.ndarray, noise_std_frac: float = 0.10, seed: int = 0) -> np.ndarray:
    rng = np.random.default_rng(seed)
    std = X.std(axis=(0, 1), keepdims=True)
    noise = rng.normal(0, noise_std_frac * std, size=X.shape)
    return (X + noise).astype(np.float32)

def inject_missingness(X: np.ndarray, missing_frac: float = 0.20, seed: int = 0) -> np.ndarray:
    rng = np.random.default_rng(seed)
    mask = rng.random(X.shape) < missing_frac
    X_missing = X.copy()
    means = X.mean(axis=1, keepdims=True)
    X_missing = np.where(mask, means, X_missing)
    return X_missing.astype(np.float32)

def robustness_eval(model, X_test: np.ndarray, y_test: np.ndarray, predict_fn,
                    noise_std_frac: float = 0.10, missing_frac: float = 0.20) -> dict:
    base_auc = roc_auc_score(y_test, predict_fn(model, X_test))
    noisy_X = inject_noise(X_test, noise_std_frac)
    noisy_auc = roc_auc_score(y_test, predict_fn(model, noisy_X))
    missing_X = inject_missingness(X_test, missing_frac)
    missing_auc = roc_auc_score(y_test, predict_fn(model, missing_X))
    return {
        "clean_auroc": float(base_auc),
        "noisy_auroc": float(noisy_auc),
        "missing_auroc": float(missing_auc),
        "noisy_degradation": float(base_auc - noisy_auc),
        "missing_degradation": float(base_auc - missing_auc),
    }

def delong_roc_variance(y_true: np.ndarray, y_prob: np.ndarray):
    order = np.argsort(-y_prob)
    y_true = y_true[order]
    y_prob = y_prob[order]
    pos = y_prob[y_true == 1]
    neg = y_prob[y_true == 0]
    m, n = len(pos), len(neg)
    if m == 0 or n == 0:
        return float("nan"), 0.0
    tx = np.empty(m)
    ty = np.empty(n)
    for i in range(m):
        tx[i] = (np.sum(pos[i] > neg) + 0.5 * np.sum(pos[i] == neg)) / n
    for j in range(n):
        ty[j] = (np.sum(neg[j] < pos) + 0.5 * np.sum(neg[j] == pos)) / m
    auc = tx.mean()
    sx = np.var(tx, ddof=1) / m if m > 1 else 0.0
    sy = np.var(ty, ddof=1) / n if n > 1 else 0.0
    return auc, sx + sy

def delong_test(y_true: np.ndarray, prob_a: np.ndarray, prob_b: np.ndarray) -> dict:
    auc_a, var_a = delong_roc_variance(y_true, prob_a)
    auc_b, var_b = delong_roc_variance(y_true, prob_b)
    var = var_a + var_b
    if var <= 0:
        return {"auc_a": auc_a, "auc_b": auc_b, "z": float("nan"), "p_value": float("nan")}
    z = (auc_a - auc_b) / np.sqrt(var)
    p = 2 * (1 - stats.norm.cdf(abs(z)))
    return {"auc_a": float(auc_a), "auc_b": float(auc_b), "z": float(z), "p_value": float(p)}

def bootstrap_metric_diff(y_true: np.ndarray, prob_a: np.ndarray, prob_b: np.ndarray,
                          n_iterations: int = 1000, seed: int = 42) -> dict:
    rng = np.random.default_rng(seed)
    n = len(y_true)
    diffs = []
    for _ in range(n_iterations):
        idx = rng.integers(0, n, n)
        yt = y_true[idx]
        if len(np.unique(yt)) < 2:
            continue
        pred_a = (prob_a[idx] >= 0.5).astype(int)
        pred_b = (prob_b[idx] >= 0.5).astype(int)
        f1_a = f1_score(yt, pred_a, zero_division=0)
        f1_b = f1_score(yt, pred_b, zero_division=0)
        diffs.append(f1_a - f1_b)
    diffs = np.array(diffs)
    return {
        "mean_diff": float(diffs.mean()),
        "ci_lower": float(np.percentile(diffs, 2.5)),
        "ci_upper": float(np.percentile(diffs, 97.5)),
        "p_value_two_sided": float(2 * min((diffs > 0).mean(), (diffs < 0).mean())),
    }
