"""
windowing.py
Builds sliding windows from hourly wide patient tables and assigns deterministic
weak anomaly labels according to clinical criteria:
  (a) Fluid overload risk: Volume change over trailing 3h > 75th percentile and urine change <= median
  (b) Dysnatremia: Serum sodium exits [130, 150] mEq/L during active infusion
  (c) Hemodynamic compromise: MAP drops > 15% below its trailing 6h rolling mean
"""

from __future__ import annotations
from dataclasses import dataclass
import numpy as np
import pandas as pd

def generate_weak_labels(wide: pd.DataFrame) -> pd.Series:
    """
    Deterministic weak anomaly labeling for saline infusion monitoring.
    """
    infusion = wide.get("saline_infusion_rate", pd.Series(0, index=wide.index))
    volume = wide.get("saline_total_volume", pd.Series(0, index=wide.index))
    urine = wide.get("urine_output", pd.Series(np.nan, index=wide.index))
    sodium = wide.get("sodium", pd.Series(np.nan, index=wide.index))
    map_ = wide.get("mean_arterial_pressure", pd.Series(np.nan, index=wide.index))

    # Active infusion flag
    active = (infusion.fillna(0) > 0) | (volume.fillna(0).diff().fillna(0) > 0)

    # Condition (a): Fluid overload risk
    vol_change = volume.diff().rolling(3, min_periods=1).sum()
    urine_change = urine.diff().rolling(3, min_periods=1).sum()
    fluid_overload = active & (vol_change > vol_change.quantile(0.75)) & (urine_change <= urine_change.median())

    # Condition (b): Dysnatremia
    dysnatremia = active & ((sodium < 130) | (sodium > 150))

    # Condition (c): Hemodynamic compromise
    map_roll = map_.rolling(6, min_periods=2).mean().shift(1)
    hemodynamic = active & (map_ < 0.85 * map_roll)

    label = (fluid_overload.fillna(False) | dysnatremia.fillna(False) | hemodynamic.fillna(False)).astype(int)
    return label

@dataclass
class WindowedSequences:
    X: np.ndarray           # [N, w, d]
    y: np.ndarray           # [N]
    stay_ids: np.ndarray     # [N]
    hours: np.ndarray        # [N]
    feature_names: list[str]

def build_windows(patient_tables: dict[int, pd.DataFrame], window_size: int, stride: int,
                  feature_order: list[str]) -> WindowedSequences:
    X_list, y_list, sid_list, hr_list = [], [], [], []
    for stay_id, wide in patient_tables.items():
        wide = wide[feature_order]
        labels = generate_weak_labels(wide)
        values = wide.values
        T = len(wide)
        if T < window_size:
            continue
        for end in range(window_size - 1, T, stride):
            start = end - window_size + 1
            window = values[start:end + 1]
            if np.isnan(window).any():
                continue
            X_list.append(window)
            y_list.append(int(labels.iloc[end]))
            sid_list.append(stay_id)
            hr_list.append(wide.index[end])
    return WindowedSequences(
        X=np.stack(X_list).astype(np.float32),
        y=np.array(y_list, dtype=np.int64),
        stay_ids=np.array(sid_list),
        hours=np.array(hr_list),
        feature_names=feature_order,
    )

def patient_wise_split(seq: WindowedSequences, train_frac: float = 0.70, val_frac: float = 0.15, seed: int = 42):
    """
    Patient-wise split to prevent leakage across patients.
    """
    rng = np.random.default_rng(seed)
    unique_ids = np.unique(seq.stay_ids)
    rng.shuffle(unique_ids)
    n = len(unique_ids)
    n_train = int(n * train_frac)
    n_val = int(n * val_frac)
    train_ids = set(unique_ids[:n_train])
    val_ids = set(unique_ids[n_train:n_train + n_val])
    test_ids = set(unique_ids[n_train + n_val:])

    def mask_for(ids):
        return np.isin(seq.stay_ids, list(ids))

    return mask_for(train_ids), mask_for(val_ids), mask_for(test_ids)

def zscore_normalize(X_train: np.ndarray, *others: np.ndarray):
    """
    Fit mean and std on TRAIN SPLIT ONLY, then transform validation and test.
    """
    mean = X_train.reshape(-1, X_train.shape[-1]).mean(axis=0)
    std = X_train.reshape(-1, X_train.shape[-1]).std(axis=0) + 1e-6
    results = [(X_train - mean) / std]
    for X in others:
        results.append((X - mean) / std)
    return results, mean, std
