"""
feature_engineering.py
Generates 104 per-window summary statistics across 13 clinical channels:
  - Level: mean, first, last
  - Dispersion: std, min, max
  - Trend: delta (last - first), slope (least-squares linear fit)
"""

from __future__ import annotations
import numpy as np

STAT_NAMES = ["mean", "std", "min", "max", "first", "last", "delta", "slope"]

def get_feature_names(channel_names: list[str]) -> list[str]:
    """Returns list of 104 feature names matching extract_window_features order."""
    return [f"{stat}_{ch}" for stat in STAT_NAMES for ch in channel_names]

def extract_window_features(X: np.ndarray) -> np.ndarray:
    """
    Extracts summary statistics for each window.
    Input:
        X: np.ndarray of shape [N, window_len, num_channels] (e.g., [N, 6, 13])
    Output:
        features: np.ndarray of shape [N, num_channels * 8] (e.g., [N, 104])
    """
    n, w, d = X.shape
    t = np.arange(w, dtype=np.float32)
    t_centered = t - t.mean()
    denom = float((t_centered ** 2).sum()) or 1.0

    mean = X.mean(axis=1)
    std = X.std(axis=1)
    minimum = X.min(axis=1)
    maximum = X.max(axis=1)
    first = X[:, 0, :]
    last = X[:, -1, :]
    delta = last - first
    x_centered = X - mean[:, None, :]
    slope = (t_centered[None, :, None] * x_centered).sum(axis=1) / denom

    return np.concatenate(
        [mean, std, minimum, maximum, first, last, delta, slope], axis=1
    ).astype(np.float32)
